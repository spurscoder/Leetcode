from setuptools import setup

setup(
    name="Leetcode",
    description="Leetcode for test",
    keywords=["good", "bad"],
    version="0.0",
    url = 'https://github.com/spurscoder/Leetcode/',
    packages=["src"],
    install_requires=[
    ]
)

