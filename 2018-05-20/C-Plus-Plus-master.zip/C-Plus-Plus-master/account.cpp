#include"account.h"
#include<iostream>
using namespace std;
double Savingsaccount::total = 0;
//SavingsAccount����س�Ա������ʵ��
Savingsaccount::Savingsaccount(int date, int id, double rate) :id(id), balance(0), rate(rate), lastdate(date), accumulation(0) {
	cout << date << "\t#" << id << "is created" << endl;
}
void Savingsaccount::record(int date, double amount) {
	accumulation = accumulate(date);
	lastdate = date;
	amount = floor(amount * 100 + 0.5) / 100;//����С�������λ
	balance = balance + amount;
	total = total + amount;
	cout << date << " \t#" << id << "\t" << amount << "\t" << balance << endl;
}
void Savingsaccount::deposit(int date, double amount) {
	record(date, amount);
}
void Savingsaccount::withdraw(int date, double amount) {
	if (amount>getbalance())
		cout << "Error : not enough money" << endl;
	else
		record(date, -amount);
}
void Savingsaccount::settle(int date) {
	double interest = accumulate(date) *rate / 365;//������Ϣ
	if (interest != 0)
		record(date, interest);
	accumulation = 0;
}
void Savingsaccount::show() const {
	cout << "#" << id << "\tBalance:" << balance;
}